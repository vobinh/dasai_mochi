#pragma once
#include <Arduino.h>
#include <pgmspace.h>

// Chronos weather icon index (0..7)
static const char* const WEATHER_LABELS[8] PROGMEM = {
  "Clear",          // 0
  "Few clouds",     // 1
  "Partly cloudy",  // 2
  "Cloudy",         // 3
  "Rain",           // 4
  "Thunderstorm",   // 5
  "Snow",           // 6
  "Mist"            // 7
};

// Clamp 0..7
static inline uint8_t getWeatherIconIndex(int idx) {
  if (idx < 0) return 0;
  if (idx > 7) return 7;
  return (uint8_t)idx;
}

// Read label from PROGMEM into buffer
static inline void getWeatherLabel(uint8_t idx, char* out, size_t outLen) {
  if (idx > 7) idx = 7;
  strncpy_P(out, (PGM_P)pgm_read_ptr(&WEATHER_LABELS[idx]), outLen);
  out[outLen - 1] = '\0';
}
